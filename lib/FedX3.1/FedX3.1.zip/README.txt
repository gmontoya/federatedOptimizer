Readme

First steps and important information:

 * Documentation can be found in doc-folder
 * Required libraries are in the lib folder
 * Mailing List: iwb-discussion (at) googlegroups.com
 * Contact: Andreas.Schwarte (at) fluidops.com
 * Project Website: http://www.fluidops.com/FedX
 * FedX is licensed under AGPL (see attached license). 

(c) 2011-2014 fluid Operations AG
http://www.fluidops.com
Last updated: 07.10.2014